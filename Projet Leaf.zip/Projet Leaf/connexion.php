<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Leaf : Connexion</title>
   <link href="css/styleConnexion.css" rel="stylesheet" media="all" type="text/css"/> 
</head>

<body background="img/background3.jpeg">
<form action="includes/login.php" method="post">
    
    
    <h1>Connexion</h1>    
    <div class="boite">	
        <p>
            <label> Adresse e-mail<br>
                <input type="email" name="mail" required >
    			
            </label>
        </p>
        
        <p>
            <label> Mot de passe <br>
                <input type="password" name="pass" required minlength="8" maxlength="16" >     
            </label>
        </p>
    </div>
    <br>
    	<input type="submit" name="submit" value="Connexion" />
    	 
    	 <a href="inscription.php"> Inscription </a>
    	 
    </form>
</body>
</html>
