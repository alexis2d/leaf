<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Archive Génerale</title>
<link href="css/styleArchivegene.css" rel="stylesheet" media="all" type="text/css"/>    
</head>

<body background="img/background3.jpeg">	
<form id="formclient" action="includes/gen.php" method="post">


<h1> Archive générale </h1>

<div class="boite">	    

 <p> 
	Recherche :
 </p>
	
	<textarea name="titre" id="recherche" placeholder="Par Titre"></textarea><br />
	
	<textarea name="tag" id="recherche" placeholder="Par Tag"></textarea><br />

</div>	
<br>
	<input type="submit" name="submit" value="Valider" />
  
	
</form>
</body>
</html>