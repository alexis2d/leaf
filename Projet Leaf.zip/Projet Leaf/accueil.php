<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Leaf : Accueil</title>
    <link href="css/styleAccueil.css" rel="stylesheet" media="all" type="text/css"/> 
</head>

<body background="img/background3.jpeg">	
<form id="formclient" action="includes/login.php" method="post">
	
<h1> Importations </h1>

<div class="petiteboite">	
  <br>
	<p>
		 <a href="importationImages.php"> Importer des images </a>
    </p>

</div>		

<h1>Archives </h1>
<div class="boite">		
    <p>
       <a href="archiveperso.php"> Archive personnelle </a>
    </p>
    
    <p> 
       <a href="archivegene.php"> Archive générale </a>
    </p>
	
	
</div>			

</form>
</body>
</html>
