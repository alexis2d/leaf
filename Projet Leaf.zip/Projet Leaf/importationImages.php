<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Projet web/bd</title>
     <link href="css/styleImportationImages.css" rel="stylesheet" media="all" type="text/css"/>   

</head>

<body background="img/background3.jpeg">    
<form method="post" action="includes/import.php">

    
<h1> Importer des images </h1> 

<div class="petiteboite">       
    <p>
        <label> Mettre url des images </label><br />
        <textarea name="img" id="img" required> </textarea><br />
    </p>
  
</div>



	<h1>Description </h1>
<div class="boite">		
    	<p>
    		<label> Titre (max. 255 caractères) :</label><br />
            <textarea name="titre" id="titre"></textarea><br />
    	</p>
    	
    	<p>
    		<label> Description de vos images (max. 300 caractères) :</label><br />
            <textarea name="description" id="description"></textarea><br />
    	</p>
    	
    	<p>
        Sélectionnez votre/vos tag(s) :
       </p> 
    
    <div class="point">
        <input type="checkbox" name="tag" value="d1" />Jeux <br/>
        <input type="checkbox" name="tag" value="d2" />Art <br/>
        <input type="checkbox" name="tag" value="d3" />Paysage <br/>
        <input type="checkbox" name="tag" value="d4" />Photo <br/>
        <input type="checkbox" name="tag" value="d5" />Manga <br/>
    </div>	
    	<p>
    	Autre (création de tag) :
    	</p>
    	
    	<textarea name="creation" id="creation" required> </textarea><br />
    	
</div>	
<br>		
        <input type="submit" name="submit" value="Envoyer" />		
</form>
</body>
</html>
