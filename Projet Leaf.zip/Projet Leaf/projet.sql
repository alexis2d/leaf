#------------------------------------------------------------
#        Script MySQL.
#------------------------------------------------------------


#------------------------------------------------------------
# Table: User
#------------------------------------------------------------

CREATE TABLE User(
        UserID    Int  Auto_increment  NOT NULL ,
        Name      Varchar (255) NOT NULL ,
        FirstName Varchar (255) NOT NULL ,
        Email     Varchar (255) NOT NULL ,
        Password  Varchar (255) NOT NULL ,
        Nickname  Varchar (30) NOT NULL
	,CONSTRAINT User_AK UNIQUE (Nickname)
	,CONSTRAINT User_PK PRIMARY KEY (UserID)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Picture
#------------------------------------------------------------

CREATE TABLE Picture(
        PictureID   Int  Auto_increment  NOT NULL ,
        Title       Varchar (50) NOT NULL ,
        Description Varchar (300) NOT NULL ,
        UploadDate  Date NOT NULL ,
        FileName    Varchar (300) NOT NULL ,
        UserID      Int NOT NULL
	,CONSTRAINT Picture_PK PRIMARY KEY (PictureID)

	,CONSTRAINT Picture_User_FK FOREIGN KEY (UserID) REFERENCES User(UserID)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Tags
#------------------------------------------------------------

CREATE TABLE Tags(
        TagID   Int  Auto_increment  NOT NULL ,
        TagName Varchar (255) NOT NULL ,
        UserID  Int NOT NULL
	,CONSTRAINT Tags_PK PRIMARY KEY (TagID)

	,CONSTRAINT Tags_User_FK FOREIGN KEY (UserID) REFERENCES User(UserID)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: Is associated to
#------------------------------------------------------------

CREATE TABLE Is_associated_to(
        TagID     Int NOT NULL ,
        PictureID Int NOT NULL
	,CONSTRAINT Is_associated_to_PK PRIMARY KEY (TagID,PictureID)

	,CONSTRAINT Is_associated_to_Tags_FK FOREIGN KEY (TagID) REFERENCES Tags(TagID)
	,CONSTRAINT Is_associated_to_Picture0_FK FOREIGN KEY (PictureID) REFERENCES Picture(PictureID)
)ENGINE=InnoDB;


#------------------------------------------------------------
# Table: is liking
#------------------------------------------------------------

CREATE TABLE Is_liking(
        PictureID Int NOT NULL ,
        UserID    Int NOT NULL
	,CONSTRAINT is_liking_PK PRIMARY KEY (PictureID,UserID)

	,CONSTRAINT is_liking_Picture_FK FOREIGN KEY (PictureID) REFERENCES Picture(PictureID)
	,CONSTRAINT is_liking_User0_FK FOREIGN KEY (UserID) REFERENCES User(UserID)
)ENGINE=InnoDB;

