<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Leaf : Inscription </title>
<link href="css/styleInscription.css" rel="stylesheet" media="all" type="text/css"/>    

</head>


<body background="img/background3.jpeg">



<h1> Inscription </h1>
<form  method="post" action="includes/insc.php">
<div class="boite">	    
    <p>
        <label> Nom <br>
            <input type="text" id="nom" name="nom" minlength="2" required >
        </label>
    </p>
    
    <p>
        <label> Prénom <br>
            <input type="text" id="prenom"   name="prenom" minlength="2" required >
        </label>
    </p>
	
    <p>
        <label> Email <br>
            <input type="email"  id="mail" name="mail" required >
			
        </label>
    </p>
    
    <p>
        <label> Mot de passe <br> 
            <input type="password" id="pass"  name="pass" required minlength="8" maxlength="16" >
        </label>
    </p>
		
<p>
<label> Pseudo <br>
	<input type="text" id="pseudo" name="pseudo" required >
        </label>
</p>
</div>

   <p class="boutons"> <input type="submit" id="Inscription" name="Inscription" value="Inscription"> <input type="reset"> </p>      
</form>
</body>
</html>
