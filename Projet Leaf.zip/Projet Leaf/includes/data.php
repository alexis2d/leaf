<?php
    define('HOST', 'localhost');
    define('DB_Name','projet');
    define('USER', 'root');
    define('PASS','');
	try{
		$db = new PDO('mysql:host=' . HOST . ';dbname=' . DB_Name, USER, PASS,array());
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		} catch(PDOException $e){
			echo $e;
		}
?>
<!-- <?php

            /*$hashpass = password_hash($password, PASSWORD_BCRYPT);*/
/*            include 'data.php';
            global $db;*/

            /*$c = $db->prepare("SELECT email From user WHERE email= :email")*/

            /*$q = $db->prepare("INSERT INTO user(Name,FirstName,Email,Gender,Password,Nickname) VALUES(:Name,:FirstName,:Email,:Gender,:Password,:Nickname)");
            $q->execute([
                'Name' => $Nom,
                'Firstname' => $prenom,
                'Email' => $email,
                'Gender' => $civ,
                'Password' => $hashpass,
                'Nickname' =>$Pseudo                 
            ]);
*/

/*
    $user = "root";
    $pass = "";
$db = new PDO('mysql:host=127.0.0.1;dbname=projets', $user, $pass);

if(isset($_POST['Inscription']))
{
    $nompersonne = htmlspecialchars($_POST['nompersonne']);
            if (!empty($_POST['nompersonne'])) {

                


                       $insertmbr = $db->prepare("INSERT INTO personne(nompersonne) VALUES(?");
                       $insertmbr->execute(array($nompersonne));
                       /*$_SESSION['comptecree'] ='Votre compte a étais crée';
                       header('Location: accueil(connecté).php');
            
            }
}
?>*/