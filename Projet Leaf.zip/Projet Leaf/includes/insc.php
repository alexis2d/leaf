<?php
session_start();
		if (filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) {
				include 'data.php';
				$pass = sha1($_POST['pass']);
				$login = $_POST['mail'];
				$records = $db->prepare('SELECT Userid,Email FROM  User WHERE Email = :login');
				$records->bindParam(':login', $login);
				$records->execute();
				$results = $records->fetch(PDO::FETCH_ASSOC);

				if ($results['pseudo'] == $_POST['pseudo']) {
						header('location:../inscription.php');
					} else {
						$req = $db->prepare('INSERT INTO `User`(`Name` ,`FirstName` ,`Email` ,`Password` ,`Nickname`) VALUES( :nom, :prenom, :mail, :pass, :pseudo )');
						$req->execute(array(
							'nom' => $_POST['nom'],
							'prenom' => $_POST['prenom'],
							'mail' => $_POST['mail'],
							'pass' => $pass,
							'pseudo' => $_POST['pseudo'],
						)) or die(print_r($req->errorInfo()));
						
						header('location:../connexion.php');
						exit;
					}
			 } else {
				echo ' tromper mot de passe ';
			}
	
 ?>
