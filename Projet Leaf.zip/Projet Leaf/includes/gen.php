<?php
session_start();
				include 'data.php';
				$img = $_POST['img'];
				$titre = $_POST['titre'];
				$description = $_POST['description'];
				$records = $db->prepare('SELECT * FROM  Picture 
				INNER JOIN Is_associated_to ON Picture.PictureID=Is_associated_to.PictureID WHERE FileName= :mail and Password = :pass');
				$records->bindParam(':img', $img);
				$records->execute();
				$results = $records->fetch(PDO::FETCH_ASSOC);	
?>
