<?php
session_start();
				include 'data.php';
				$img = $_POST['img'];
				$titre = $_POST['titre'];
				$tag = $_POST['creation'];
				$description = $_POST['description'];
				$records = $db->prepare('SELECT * FROM `Picture` WHERE FileName = :img ');
				$records->bindParam(':img', $img);
				$records->execute();
				$results = $records->fetch(PDO::FETCH_ASSOC);
				
				if ($results['FileName'] == $_POST['img']) {
						header('location:../importationImage.php');
					} else {
						$req =$db->prepare('INSERT INTO `Picture`(`Title` ,`UploadDate` ,`Description` ,`FileName`,`UserID`) VALUES (:titre, NOW(), :description, :img, :UserID)');
						$req->execute(array(
							'titre' => $_POST['titre'],
							'description' => $_POST['description'],
							'img' => $img,
							'UserID' => $_SESSION['UserID'],
						)) or die(print_r($req->errorInfo()));
						
						$pid = $db->prepare('SELECT PictureID FROM `Picture` WHERE  FileName = :img ');
						$pid->bindParam(':img', $img);
						$pid->execute();
						$pic='';
						while ($picid = $pid->fetch(PDO::FETCH_ASSOC))
						{
							$pic = $picid['PictureID'];
						}
						echo $pic;
						
						
						$tags =$db->prepare('INSERT INTO `Tags`(`TagName`,`UserID`) VALUES (:tag, :UserID)');
						$tags->execute(array(
							'tag' => $tag,
							'UserID' => $_SESSION['UserID'],
						)) or die(print_r($tags->errorInfo()));
						
						$tid = $db->prepare('SELECT TagID FROM `Tags` WHERE  TagName = :tag ');
						$tid->bindParam(':tag',$tag);
						$tid->execute();
						$tagid = $tid->fetch(PDO::FETCH_ASSOC);
						$tagsid = $tagid['TagID'];
						//$_SESSION['PictureID'] = $results['PictureID'];
						
						
						$as =$db->prepare('INSERT INTO `Is_associated_to`(`TagID`,`PictureID`) VALUES (:tagid, :picsid)');
						$as->execute(array(
							'tagid' => $tagsid,
							'picsid' => $pic,
						)) or die(print_r($as->errorInfo()));
						
						header('location:../accueil.php');
						exit;
					}
?>
