<?php
session_start();
				include 'data.php';
				$pass = sha1($_POST['pass']);
				$mail = trim($_POST['mail']);
				$records = $db->prepare('SELECT UserID,Email,Password FROM  User WHERE Email = :mail and Password = :pass');
				$records->bindParam(':mail', $mail);
				$records->bindParam(':pass', $pass);
				$records->execute();
				$results = $records->fetch(PDO::FETCH_ASSOC);

				if (count($results) >0 && $pass == ($results['Password'])){
					$_SESSION['mail'] = $results['mail'];
					$_SESSION['pass'] = $results['pass'];
					$_SESSION['UserID'] = $results['UserID'];
					header('location:../accueil.php');
					exit;
				}else
				{
				header('location:../connexion.php');
}
?>
