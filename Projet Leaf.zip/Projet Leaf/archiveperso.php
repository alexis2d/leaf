<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Archive personnel </title>
 <link href="css/styleArchivegene.css" rel="stylesheet" media="all" type="text/css"/>   

</head>

<body background="img/background3.jpeg">    
    <form id="formclient" action="includes/perso.php" method="post">
        
    <h1> Votre archive </h1>
    	
    <div class="boite">    
     <p> 
    	Recherche :
     </p>
    	
   <textarea name="recherche" id="recherche" placeholder="Par titre"></textarea><br />
        
        <textarea name="recherche" id="recherche" placeholder="Par tag"></textarea><br />
    
    </div>
    <br>
    	<input type="submit" name="submit" value="Valider" />
    	
    
    </form>
</body>
</html>
